package homeworkeight;

public class Main {
    public static void main(String[] args) {
        MagicButton magicButton = new MagicButton("Волшебная кнопка");
    }
}
